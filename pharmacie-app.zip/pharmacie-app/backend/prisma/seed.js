import { PrismaClient } from "@prisma/client";
import bcrypt from "bcrypt";
const p = new PrismaClient();
const password = await bcrypt.hash("Changer123!", 10);
for (const [name, email, role] of [["Administrateur", "admin@pharma.local", "ADMIN"], ["Responsable", "responsable@pharma.local", "RESPONSABLE"], ["Client Test", "client@pharma.local", "CLIENT"]])
  await p.user.upsert({ where: { email }, update: {}, create: { name, email, role, password } });
const cats = [];
for (const name of ["Antalgiques", "Antibiotiques", "Vitamines", "Digestion", "Hygiène"]) cats.push(await p.category.upsert({ where: { name }, update: {}, create: { name } }));
const sup = (await p.supplier.findFirst()) || (await p.supplier.create({ data: { name: "Grossiste Central" } }));
const meds = [
  ["Doliprane", "Paracétamol", "500 mg", "Comprimé", 0, 1500, false], ["Ibuprofène Biogaran", "Ibuprofène", "400 mg", "Comprimé", 0, 2200, false],
  ["Amoxicilline Arrow", "Amoxicilline", "1 g", "Gélule", 1, 6500, true], ["Azithromycine", "Azithromycine", "250 mg", "Comprimé", 1, 9800, true],
  ["Vitamine C Upsa", "Acide ascorbique", "1000 mg", "Effervescent", 2, 7200, false], ["Magnésium B6", "Magnésium", "300 mg", "Comprimé", 2, 5400, false],
  ["Smecta", "Diosmectite", "3 g", "Sachet", 3, 3800, false], ["Gel hydroalcoolique", "Éthanol", "100 ml", "Gel", 4, 4500, false],
];
for (const [i, [name, activeIngredient, dosage, form, c, price, requiresRx]] of meds.entries()) {
  const m = await p.medication.upsert({ where: { reference: `MED-${i + 1}` }, update: {}, create: { name, activeIngredient, dosage, form, reference: `MED-${i + 1}`, price, requiresRx, minStock: 15, categoryId: cats[c].id } });
  if (!(await p.medicationBatch.count({ where: { medicationId: m.id } })))
    await p.medicationBatch.createMany({ data: [
      { medicationId: m.id, supplierId: sup.id, lotNumber: `L${i + 1}A`, expiryDate: new Date(Date.now() + (i === 3 ? 30 : 240) * 864e5), quantity: i === 5 ? 8 : 60, costPrice: price * 0.7 },
      { medicationId: m.id, supplierId: sup.id, lotNumber: `L${i + 1}B`, expiryDate: new Date(Date.now() + 500 * 864e5), quantity: i === 5 ? 0 : 80, costPrice: price * 0.7 }] });
}
console.log("Données de démonstration ajoutées");
await p.$disconnect();

import { PrismaClient, Prisma } from "@prisma/client";
export const prisma = new PrismaClient();
const D = (n) => new Prisma.Decimal(n);
export class HttpError extends Error { constructor(status, message) { super(message); this.status = status; } }
const lock = (tx, medicationId) => tx.$queryRaw`SELECT id FROM MedicationBatch WHERE medicationId = ${medicationId} FOR UPDATE`;

// Lots non périmés triés FEFO (péremption la plus proche d'abord), quantité libre = quantité - réservations actives
async function freeBatches(tx, medicationId) {
  const batches = await tx.medicationBatch.findMany({ where: { medicationId, quantity: { gt: 0 }, expiryDate: { gt: new Date() } }, orderBy: { expiryDate: "asc" } });
  const res = await tx.stockReservation.groupBy({ by: ["batchId"], where: { status: "ACTIVE", batchId: { in: batches.map((b) => b.id) } }, _sum: { quantity: true } });
  const r = Object.fromEntries(res.map((x) => [x.batchId, x._sum.quantity]));
  return batches.map((b) => ({ ...b, free: b.quantity - (r[b.id] || 0) })).filter((b) => b.free > 0);
}
export async function available(tx, medicationId) {
  return (await freeBatches(tx, medicationId)).reduce((s, b) => s + b.free, 0);
}
async function allocate(tx, medicationId, qty) {
  await lock(tx, medicationId);
  let need = qty; const parts = [];
  for (const b of await freeBatches(tx, medicationId)) {
    if (need <= 0) break;
    const take = Math.min(b.free, need);
    parts.push({ batchId: b.id, quantity: take }); need -= take;
  }
  if (need > 0) throw new HttpError(409, "Stock insuffisant");
  return parts;
}
async function takeFromBatch(tx, batchId, quantity, userId, reason) {
  const { count } = await tx.medicationBatch.updateMany({ where: { id: batchId, quantity: { gte: quantity } }, data: { quantity: { decrement: quantity } } });
  if (!count) throw new HttpError(409, "Stock insuffisant");
  await tx.stockMovement.create({ data: { type: "SORTIE_VENTE", batchId, quantity, reason, userId } });
}
export const num = (p) => p + Date.now().toString(36).toUpperCase() + Math.floor(Math.random() * 100);

export async function alerts(tx, ids) {
  for (const id of new Set(ids)) {
    const m = await tx.medication.findUnique({ where: { id } });
    const a = await available(tx, id);
    const type = a <= 0 ? "RUPTURE" : a <= m.minStock ? "STOCK_FAIBLE" : null;
    if (!type) continue;
    if (!(await tx.notification.findFirst({ where: { type, medicationId: id, read: false } })))
      await tx.notification.create({ data: { type, medicationId: id, message: type === "RUPTURE" ? `${m.name} est en rupture de stock` : `${m.name} : stock faible (${a} restants)` } });
  }
}
export async function expiryAlerts() {
  const bs = await prisma.medicationBatch.findMany({ where: { quantity: { gt: 0 }, expiryDate: { lt: new Date(Date.now() + 60 * 864e5) } }, include: { medication: true } });
  for (const b of bs) {
    const message = `${b.medication.name} (lot ${b.lotNumber}) expire le ${b.expiryDate.toLocaleDateString("fr-FR")}`;
    if (!(await prisma.notification.findFirst({ where: { type: "PEREMPTION", message } })))
      await prisma.notification.create({ data: { type: "PEREMPTION", message, medicationId: b.medicationId } });
  }
}

async function recordSale(tx, { userId, customerId = null, orderId = null, paymentMethod, lines }) {
  let total = D(0); const items = [];
  for (const l of lines) for (const p of l.parts) {
    await takeFromBatch(tx, p.batchId, p.quantity, userId, "Vente");
    items.push({ medicationId: l.medicationId, batchId: p.batchId, quantity: p.quantity, unitPrice: l.unitPrice });
    total = total.add(D(l.unitPrice).mul(p.quantity));
  }
  const n = num("");
  const sale = await tx.sale.create({ data: { number: "V-" + n, userId, customerId, orderId, paymentMethod, total, items: { create: items } } });
  await tx.invoice.create({ data: { number: "F-" + n, saleId: sale.id } });
  await alerts(tx, lines.map((l) => l.medicationId));
  return sale;
}
export async function sellCounter(tx, { items, userId, customerId, paymentMethod }) {
  const merged = new Map();
  for (const i of items) merged.set(i.medicationId, (merged.get(i.medicationId) || 0) + i.quantity);
  const lines = [];
  for (const [id, qty] of merged) {
    const m = await tx.medication.findFirst({ where: { id, archived: false } });
    if (!m) throw new HttpError(404, "Médicament introuvable");
    lines.push({ medicationId: id, unitPrice: m.price, parts: await allocate(tx, id, qty) });
  }
  return recordSale(tx, { userId, customerId, paymentMethod, lines });
}
export async function reserveOrder(tx, order) {
  for (const it of order.items)
    for (const p of await allocate(tx, it.medicationId, it.quantity))
      await tx.stockReservation.create({ data: { orderItemId: it.id, ...p } });
}
export const releaseOrder = (tx, orderId) => tx.stockReservation.updateMany({ where: { status: "ACTIVE", orderItem: { orderId } }, data: { status: "LIBEREE" } });
export async function sellOrder(tx, order, userId, paymentMethod) {
  const res = await tx.stockReservation.findMany({ where: { status: "ACTIVE", orderItem: { orderId: order.id } }, include: { orderItem: true } });
  if (!res.length) throw new HttpError(409, "Aucune réservation active pour cette commande");
  const by = new Map();
  for (const r of res) {
    const k = r.orderItem.medicationId;
    if (!by.has(k)) by.set(k, { medicationId: k, unitPrice: r.orderItem.unitPrice, parts: [] });
    by.get(k).parts.push({ batchId: r.batchId, quantity: r.quantity });
  }
  const sale = await recordSale(tx, { userId, customerId: order.userId, orderId: order.id, paymentMethod, lines: [...by.values()] });
  await tx.stockReservation.updateMany({ where: { id: { in: res.map((r) => r.id) } }, data: { status: "CONSOMMEE" } });
  return sale;
}

import "dotenv/config";
import express from "express";
import cookieParser from "cookie-parser";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import PDFDocument from "pdfkit";
import { z, ZodError } from "zod";
import { prisma, HttpError, available, alerts, reserveOrder, releaseOrder, sellCounter, sellOrder, expiryAlerts, num } from "./stock.js";

const app = express();
app.use(express.json());
app.use(cookieParser());
const h = (fn) => (req, res, next) => fn(req, res).catch(next);
const STAFF = ["ADMIN", "RESPONSABLE"];
const auth = (...roles) => (req, res, next) => {
  try {
    const u = jwt.verify(req.cookies.token, process.env.JWT_SECRET);
    if (roles.length && !roles.includes(u.role)) return res.status(403).json({ error: "Accès refusé" });
    req.user = u; next();
  } catch { res.status(401).json({ error: "Non connecté" }); }
};
const audit = (userId, action, detail) => prisma.auditLog.create({ data: { userId, action, detail } });
const items = z.array(z.object({ medicationId: z.number().int(), quantity: z.number().int().min(1).max(500) })).min(1);
const setCookie = (res, u) => res.cookie("token", jwt.sign({ id: u.id, name: u.name, email: u.email, role: u.role }, process.env.JWT_SECRET, { expiresIn: "8h" }), { httpOnly: true, sameSite: "lax", maxAge: 8 * 36e5 });

// ---- Auth
app.post("/api/auth/register", h(async (req, res) => {
  const d = z.object({ name: z.string().min(2), email: z.string().email(), password: z.string().min(8), phone: z.string().optional() }).parse(req.body);
  if (await prisma.user.findUnique({ where: { email: d.email } })) throw new HttpError(409, "Email déjà utilisé");
  const u = await prisma.user.create({ data: { ...d, password: await bcrypt.hash(d.password, 10), role: "CLIENT" } });
  setCookie(res, u); res.status(201).json({ id: u.id, name: u.name, email: u.email, role: u.role });
}));
app.post("/api/auth/login", h(async (req, res) => {
  const { email, password } = z.object({ email: z.string().email(), password: z.string().min(1) }).parse(req.body);
  const u = await prisma.user.findUnique({ where: { email } });
  if (!u || !u.active || !(await bcrypt.compare(password, u.password))) throw new HttpError(401, "Identifiants incorrects");
  setCookie(res, u); await audit(u.id, "LOGIN");
  res.json({ id: u.id, name: u.name, email: u.email, role: u.role });
}));
app.post("/api/auth/logout", (req, res) => res.clearCookie("token").json({ ok: true }));
app.get("/api/auth/me", auth(), (req, res) => res.json(req.user));

// ---- Catalogue client (jamais de prix d'achat ni de quantités)
app.get("/api/categories", h(async (req, res) => res.json(await prisma.category.findMany({ orderBy: { name: "asc" } }))));
app.get("/api/catalog", h(async (req, res) => {
  const { q = "", category } = req.query;
  const meds = await prisma.medication.findMany({ where: { archived: false, ...(category && { categoryId: +category }), OR: [{ name: { contains: q } }, { activeIngredient: { contains: q } }] }, include: { category: true }, take: 60 });
  res.json(await Promise.all(meds.map(async (m) => ({ id: m.id, name: m.name, activeIngredient: m.activeIngredient, dosage: m.dosage, form: m.form, price: m.price, category: m.category.name, requiresRx: m.requiresRx, inStock: (await available(prisma, m.id)) > 0 }))));
}));

// ---- Médicaments et lots (personnel)
app.get("/api/medications", auth(...STAFF), h(async (req, res) => {
  const meds = await prisma.medication.findMany({ where: { archived: false }, include: { category: true } });
  res.json(await Promise.all(meds.map(async (m) => ({ ...m, stock: await available(prisma, m.id) }))));
}));
app.post("/api/medications", auth(...STAFF), h(async (req, res) => {
  const d = z.object({ name: z.string().min(1), activeIngredient: z.string(), dosage: z.string(), form: z.string(), reference: z.string(), barcode: z.string().optional(), price: z.number().positive(), minStock: z.number().int().min(0).default(10), requiresRx: z.boolean().default(false), categoryId: z.number().int() }).parse(req.body);
  const m = await prisma.medication.create({ data: d }); await audit(req.user.id, "MED_CREATE", m.name); res.status(201).json(m);
}));
app.post("/api/medications/:id/batches", auth(...STAFF), h(async (req, res) => {
  const d = z.object({ lotNumber: z.string(), expiryDate: z.coerce.date(), quantity: z.number().int().min(1), costPrice: z.number().min(0), supplierId: z.number().int().optional() }).parse(req.body);
  const b = await prisma.$transaction(async (tx) => {
    const b = await tx.medicationBatch.create({ data: { ...d, medicationId: +req.params.id } });
    await tx.stockMovement.create({ data: { type: "ENTREE", batchId: b.id, quantity: d.quantity, reason: "Réception", userId: req.user.id } });
    return b;
  });
  res.status(201).json(b);
}));

// ---- Ventes au comptoir et factures PDF
app.post("/api/sales", auth(...STAFF), h(async (req, res) => {
  const d = z.object({ items, customerId: z.number().int().optional(), paymentMethod: z.enum(["ESPECES", "CARTE", "MOBILE_MONEY"]).default("ESPECES") }).parse(req.body);
  const sale = await prisma.$transaction((tx) => sellCounter(tx, { ...d, userId: req.user.id }));
  await audit(req.user.id, "SALE", sale.number); res.status(201).json(sale);
}));
app.get("/api/sales/:id/invoice.pdf", auth(), h(async (req, res) => {
  const s = await prisma.sale.findUnique({ where: { id: +req.params.id }, include: { invoice: true, seller: true, customer: true, order: true, items: { include: { medication: true } } } });
  if (!s) throw new HttpError(404, "Facture introuvable");
  if (req.user.role === "CLIENT" && s.customerId !== req.user.id) throw new HttpError(403, "Accès refusé");
  const ar = (n) => Number(n).toLocaleString("fr-FR") + " Ar";
  res.type("pdf").set("Content-Disposition", `inline; filename="${s.invoice.number}.pdf"`);
  const doc = new PDFDocument({ margin: 50 }); doc.pipe(res);
  doc.fontSize(22).fillColor("#0f766e").text(process.env.PHARMACY_NAME || "Pharmacie");
  doc.fontSize(10).fillColor("#475569").text(`Facture ${s.invoice.number}  |  Vente ${s.number}${s.order ? "  |  Commande " + s.order.number : ""}`)
    .text(`Date : ${s.createdAt.toLocaleString("fr-FR")}`).text(`Client : ${s.customer?.name || "Vente comptoir"}`).text(`Vendeur : ${s.seller.name}`).moveDown();
  doc.fillColor("#0f172a").fontSize(11);
  for (const i of s.items) doc.text(`${i.medication.name} ${i.medication.dosage}  x${i.quantity}  @ ${ar(i.unitPrice)}  =  ${ar(Number(i.unitPrice) * i.quantity)}`);
  doc.moveDown().fontSize(14).text(`Total : ${ar(s.total)}`, { align: "right" }).fontSize(10).fillColor("#475569").text(`Paiement : ${s.paymentMethod}`, { align: "right" });
  doc.moveDown(3).fontSize(9).text("Merci de votre confiance. Conservez cette facture.", { align: "center" });
  doc.end();
}));

// ---- Commandes
app.post("/api/orders", auth("CLIENT"), h(async (req, res) => {
  const d = z.object({ items }).parse(req.body);
  const order = await prisma.$transaction(async (tx) => {
    const data = [];
    for (const it of d.items) {
      const m = await tx.medication.findFirst({ where: { id: it.medicationId, archived: false } });
      if (!m) throw new HttpError(404, "Médicament introuvable");
      if ((await available(tx, m.id)) < it.quantity) throw new HttpError(409, `Stock insuffisant : ${m.name}`);
      data.push({ medicationId: m.id, quantity: it.quantity, unitPrice: m.price });
    }
    return tx.order.create({ data: { number: num("C-"), userId: req.user.id, items: { create: data } } });
  });
  res.status(201).json(order);
}));
const orderInclude = { items: { include: { medication: true } }, sale: true, user: { select: { name: true } } };
app.get("/api/orders/mine", auth("CLIENT"), h(async (req, res) => res.json(await prisma.order.findMany({ where: { userId: req.user.id }, include: orderInclude, orderBy: { id: "desc" } }))));
app.get("/api/orders", auth(...STAFF), h(async (req, res) => res.json(await prisma.order.findMany({ include: orderInclude, orderBy: { id: "desc" }, take: 100 }))));
const FLOW = { EN_ATTENTE: ["CONFIRMEE", "ANNULEE"], CONFIRMEE: ["EN_PREPARATION", "ANNULEE"], EN_PREPARATION: ["PRETE", "ANNULEE"], PRETE: ["LIVREE", "ANNULEE"], LIVREE: [], ANNULEE: [] };
app.patch("/api/orders/:id/status", auth(...STAFF), h(async (req, res) => {
  const { status, comment, paymentMethod } = z.object({ status: z.enum(Object.keys(FLOW)), comment: z.string().optional(), paymentMethod: z.string().default("ESPECES") }).parse(req.body);
  await prisma.$transaction(async (tx) => {
    const o = await tx.order.findUnique({ where: { id: +req.params.id }, include: { items: true } });
    if (!o) throw new HttpError(404, "Commande introuvable");
    if (!FLOW[o.status].includes(status)) throw new HttpError(400, `Passage ${o.status} → ${status} impossible`);
    if (status === "CONFIRMEE") await reserveOrder(tx, o);
    if (status === "ANNULEE") await releaseOrder(tx, o.id);
    if (status === "LIVREE") await sellOrder(tx, o, req.user.id, paymentMethod);
    await tx.order.update({ where: { id: o.id }, data: { status, comment } });
    await alerts(tx, o.items.map((i) => i.medicationId));
  });
  await audit(req.user.id, "ORDER_STATUS", `${req.params.id} → ${status}`); res.json({ ok: true });
}));

// ---- Notifications et tableau de bord
app.patch("/api/notifications/:id/read", auth(...STAFF), h(async (req, res) => { await prisma.notification.update({ where: { id: +req.params.id }, data: { read: true } }); res.json({ ok: true }); }));
app.get("/api/dashboard", auth(...STAFF), h(async (req, res) => {
  const day = new Date(); day.setHours(0, 0, 0, 0);
  const since = new Date(day); since.setDate(since.getDate() - 6);
  const [activeMeds, users, orders, sales, today, pending, expiring, weekSales, lines, recent, notifs, meds] = await Promise.all([
    prisma.medication.count({ where: { archived: false } }), prisma.user.count(), prisma.order.count(), prisma.sale.count(),
    prisma.sale.aggregate({ where: { createdAt: { gte: day } }, _sum: { total: true }, _count: true }),
    prisma.order.count({ where: { status: "EN_ATTENTE" } }),
    prisma.medicationBatch.count({ where: { quantity: { gt: 0 }, expiryDate: { lt: new Date(Date.now() + 60 * 864e5) } } }),
    prisma.sale.findMany({ where: { createdAt: { gte: since } }, select: { total: true, createdAt: true } }),
    prisma.saleItem.findMany({ where: { sale: { createdAt: { gte: new Date(Date.now() - 30 * 864e5) } } }, include: { medication: { include: { category: true } } } }),
    prisma.sale.findMany({ orderBy: { id: "desc" }, take: 6, include: { customer: { select: { name: true } } } }),
    prisma.notification.findMany({ where: { read: false }, orderBy: { id: "desc" }, take: 8 }),
    prisma.medication.findMany({ where: { archived: false } }),
  ]);
  const week = Array.from({ length: 7 }, (_, i) => { const d = new Date(since); d.setDate(d.getDate() + i); return { key: d.toDateString(), d: d.toLocaleDateString("fr-FR", { weekday: "short" }), v: 0 }; });
  for (const s of weekSales) { const w = week.find((x) => x.key === s.createdAt.toDateString()); if (w) w.v += Number(s.total); }
  const cat = {};
  for (const l of lines) cat[l.medication.category.name] = (cat[l.medication.category.name] || 0) + Number(l.unitPrice) * l.quantity;
  const stocks = await Promise.all(meds.map(async (m) => ({ min: m.minStock, stock: await available(prisma, m.id) })));
  res.json({ activeMeds, users, orders, sales, todayRevenue: Number(today._sum.total || 0), todaySales: today._count, pending, expiring,
    lowStock: stocks.filter((s) => s.stock > 0 && s.stock <= s.min).length, outOfStock: stocks.filter((s) => s.stock <= 0).length,
    week, byCategory: Object.entries(cat).map(([name, value]) => ({ name, value })), recent, notifs });
}));

// ---- Utilisateurs (admin)
app.get("/api/users", auth("ADMIN"), h(async (req, res) => res.json(await prisma.user.findMany({ select: { id: true, name: true, email: true, role: true, active: true } }))));
app.post("/api/users", auth("ADMIN"), h(async (req, res) => {
  const d = z.object({ name: z.string().min(2), email: z.string().email(), password: z.string().min(8), role: z.enum(["ADMIN", "RESPONSABLE", "CLIENT"]) }).parse(req.body);
  const u = await prisma.user.create({ data: { ...d, password: await bcrypt.hash(d.password, 10) } });
  await audit(req.user.id, "USER_CREATE", u.email); res.status(201).json({ id: u.id });
}));
app.patch("/api/users/:id", auth("ADMIN"), h(async (req, res) => {
  const d = z.object({ active: z.boolean().optional(), role: z.enum(["ADMIN", "RESPONSABLE", "CLIENT"]).optional() }).parse(req.body);
  await prisma.user.update({ where: { id: +req.params.id }, data: d }); await audit(req.user.id, "USER_UPDATE", `${req.params.id}`); res.json({ ok: true });
}));

app.use((err, req, res, next) => {
  if (err instanceof ZodError) return res.status(400).json({ error: "Données invalides", details: err.issues });
  if (err instanceof HttpError) return res.status(err.status).json({ error: err.message });
  console.error(err); res.status(500).json({ error: "Erreur serveur" });
});
app.listen(process.env.PORT || 4000, () => console.log("API sur http://localhost:" + (process.env.PORT || 4000)));
expiryAlerts(); setInterval(expiryAlerts, 864e5);

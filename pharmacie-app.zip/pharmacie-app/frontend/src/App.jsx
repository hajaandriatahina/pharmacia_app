import { useEffect, useState } from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import { api } from "./api.js";
import { AuthCtx } from "./auth.js";
import Login from "./pages/Login.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import Storefront from "./pages/Storefront.jsx";

export default function App() {
  const [user, setUser] = useState(undefined);
  useEffect(() => { api.get("/auth/me").then((r) => setUser(r.data)).catch(() => setUser(null)); }, []);
  if (user === undefined) return null;
  const logout = async () => { await api.post("/auth/logout"); setUser(null); };
  const staff = user && user.role !== "CLIENT";
  return (
    <AuthCtx.Provider value={{ user, setUser, logout }}>
      <Routes>
        <Route path="/login" element={user ? <Navigate to={staff ? "/admin" : "/"} /> : <Login />} />
        <Route path="/admin" element={staff ? <Dashboard /> : <Navigate to="/login" />} />
        <Route path="/" element={!user ? <Navigate to="/login" /> : staff ? <Navigate to="/admin" /> : <Storefront />} />
      </Routes>
    </AuthCtx.Provider>
  );
}

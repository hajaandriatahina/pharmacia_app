import { useEffect, useState } from "react";
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, Tooltip, ResponsiveContainer } from "recharts";
import { LayoutDashboard, LogOut, HeartPulse, Pill, Wallet, Users, TimerReset, BellRing, Check } from "lucide-react";
import { api, fmt } from "../api.js";
import { useAuth } from "../auth.js";

const tones = ["bg-emerald-200", "bg-teal-200", "bg-rose-200", "bg-violet-200"];
const pastel = ["#a7f3d0", "#99f6e4", "#fecdd3", "#ddd6fe", "#fde68a"];

function useCount(n) {
  const [v, setV] = useState(0);
  useEffect(() => {
    let f, t0;
    const step = (t) => { t0 ??= t; const p = Math.min((t - t0) / 800, 1); setV(Math.round(n * p)); if (p < 1) f = requestAnimationFrame(step); };
    f = requestAnimationFrame(step);
    return () => cancelAnimationFrame(f);
  }, [n]);
  return v;
}
function Stat({ label, value, money, icon: Icon, i }) {
  const v = useCount(value);
  return (
    <div className={`${tones[i]} animate-rise rounded-3xl p-5 transition duration-300 hover:-translate-y-1`} style={{ animationDelay: `${i * 80}ms` }}>
      <div className="flex items-center justify-between text-slate-700"><p className="text-sm">{label}</p><Icon size={18} /></div>
      <p className="mt-4 text-3xl font-semibold text-slate-900">{money ? fmt(v) : v}</p>
    </div>
  );
}

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [d, setD] = useState(null);
  const load = () => api.get("/dashboard").then((r) => setD(r.data));
  useEffect(() => { load(); }, []);
  const read = async (id) => { await api.patch(`/notifications/${id}/read`); load(); };
  if (!d) return <div className="grid min-h-screen place-items-center bg-emerald-50 text-slate-500">Chargement…</div>;
  const total = d.byCategory.reduce((s, c) => s + c.value, 0);

  return (
    <div className="flex min-h-screen gap-5 bg-emerald-50 p-4">
      <aside className="hidden w-60 shrink-0 flex-col rounded-3xl bg-white p-5 shadow-sm lg:flex">
        <div className="mb-8 flex items-center gap-2 text-lg font-semibold text-emerald-800"><HeartPulse /> Pharma-SHOP</div>
        <p className="mb-2 px-3 text-xs text-slate-400">Menu</p>
        <button className="flex items-center gap-3 rounded-2xl bg-[#0f3d36] px-4 py-3 text-sm font-medium text-white"><LayoutDashboard size={18} /> Tableau de bord</button>
        <button onClick={logout} className="mt-auto flex items-center gap-3 rounded-2xl px-4 py-3 text-sm text-slate-600 transition hover:bg-slate-100"><LogOut size={18} /> Déconnexion</button>
      </aside>

      <main className="min-w-0 flex-1 space-y-5">
        <header className="animate-rise flex items-center justify-between rounded-3xl bg-white px-6 py-4 shadow-sm">
          <h1 className="text-xl font-semibold text-slate-900">Bonjour, {user.name}</h1>
          <span className="flex items-center gap-2 rounded-full bg-emerald-50 px-3 py-1.5 text-sm text-emerald-800"><BellRing size={16} /> {d.notifs.length} alerte(s)</span>
        </header>

        <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <Stat i={0} label="Ventes du jour" value={d.todayRevenue} money icon={Wallet} />
          <Stat i={1} label="Médicaments actifs" value={d.activeMeds} icon={Pill} />
          <Stat i={2} label="Lots à péremption proche" value={d.expiring} icon={TimerReset} />
          <Stat i={3} label={user.role === "ADMIN" ? "Utilisateurs" : "Commandes en attente"} value={user.role === "ADMIN" ? d.users : d.pending} icon={Users} />
        </section>

        <section className="grid gap-5 xl:grid-cols-3">
          <div className="animate-rise rounded-3xl bg-white p-6 shadow-sm" style={{ animationDelay: "200ms" }}>
            <h2 className="font-semibold text-slate-900">Ventes par catégorie (30 j)</h2>
            <div className="relative h-56">
              <ResponsiveContainer><PieChart><Pie data={d.byCategory.length ? d.byCategory : [{ name: "Aucune vente", value: 1 }]} dataKey="value" innerRadius={60} outerRadius={90} paddingAngle={3} cornerRadius={8}>
                {d.byCategory.map((_, i) => <Cell key={i} fill={pastel[i % 5]} />)}
              </Pie><Tooltip formatter={(v) => fmt(v)} /></PieChart></ResponsiveContainer>
              <div className="pointer-events-none absolute inset-0 grid place-items-center text-center"><div><p className="text-xs text-slate-400">Total</p><p className="text-sm font-semibold">{fmt(total)}</p></div></div>
            </div>
            <div className="mt-2 flex flex-wrap gap-3 text-xs text-slate-600">{d.byCategory.map((c, i) => <span key={c.name} className="flex items-center gap-1"><i className="h-2.5 w-2.5 rounded-full" style={{ background: pastel[i % 5] }} />{c.name}</span>)}</div>
          </div>

          <div className="animate-rise rounded-3xl bg-white p-6 shadow-sm xl:col-span-2" style={{ animationDelay: "280ms" }}>
            <h2 className="mb-4 font-semibold text-slate-900">Ventes des 7 derniers jours</h2>
            <div className="h-60"><ResponsiveContainer><BarChart data={d.week}>
              <XAxis dataKey="d" tickLine={false} axisLine={false} fontSize={12} />
              <Tooltip formatter={(v) => fmt(v)} cursor={{ fill: "#ecfdf5" }} contentStyle={{ borderRadius: 14, border: 0, background: "#0f3d36", color: "#fff" }} labelStyle={{ color: "#a7f3d0" }} />
              <Bar dataKey="v" radius={[16, 16, 16, 16]} barSize={30}>{d.week.map((_, i) => <Cell key={i} fill={pastel[i % 5]} />)}</Bar>
            </BarChart></ResponsiveContainer></div>
          </div>
        </section>

        <section className="grid gap-5 xl:grid-cols-3">
          <div className="animate-rise rounded-3xl bg-white p-6 shadow-sm xl:col-span-2" style={{ animationDelay: "340ms" }}>
            <h2 className="mb-3 font-semibold text-slate-900">Dernières ventes</h2>
            {d.recent.length === 0 ? <p className="text-sm text-slate-500">Aucune vente pour le moment.</p> : (
              <table className="w-full text-left text-sm"><thead className="text-slate-400"><tr><th className="py-2 font-medium">Vente</th><th className="font-medium">Client</th><th className="font-medium">Paiement</th><th className="text-right font-medium">Total</th></tr></thead>
                <tbody className="divide-y divide-slate-100">{d.recent.map((s) => (
                  <tr key={s.id} className="transition hover:bg-emerald-50/60"><td className="py-3 font-medium">
                    <a className="text-emerald-700 hover:underline" href={`/api/sales/${s.id}/invoice.pdf`} target="_blank" rel="noreferrer">{s.number}</a></td>
                    <td>{s.customer?.name || "Comptoir"}</td><td>{s.paymentMethod}</td><td className="text-right">{fmt(s.total)}</td></tr>))}</tbody></table>)}
          </div>
          <div className="animate-rise rounded-3xl bg-white p-6 shadow-sm" style={{ animationDelay: "400ms" }}>
            <h2 className="mb-3 font-semibold text-slate-900">Alertes</h2>
            <p className="mb-3 text-xs text-slate-500">{d.lowStock} stock faible · {d.outOfStock} rupture(s)</p>
            {d.notifs.length === 0 ? <p className="text-sm text-slate-500">Tout est en ordre.</p> : (
              <ul className="space-y-2">{d.notifs.map((n) => (
                <li key={n.id} className="animate-pop flex items-start justify-between gap-2 rounded-2xl bg-rose-50 px-3 py-2 text-sm text-rose-900">
                  <span>{n.message}</span>
                  <button aria-label="Marquer comme lu" onClick={() => read(n.id)} className="rounded-full p-1 transition hover:bg-rose-200"><Check size={16} /></button>
                </li>))}</ul>)}
          </div>
        </section>
      </main>
    </div>
  );
}

import { useEffect, useState } from "react";
import { Search, ShoppingCart, Pill, Plus, Minus, X, LogOut, Package, FileText, ShieldCheck } from "lucide-react";
import { api, fmt } from "../api.js";
import { useAuth } from "../auth.js";

const STATUS = { EN_ATTENTE: "bg-amber-100 text-amber-700", CONFIRMEE: "bg-blue-100 text-blue-700", EN_PREPARATION: "bg-indigo-100 text-indigo-700", PRETE: "bg-emerald-100 text-emerald-700", LIVREE: "bg-slate-100 text-slate-600", ANNULEE: "bg-rose-100 text-rose-700" };

export default function Storefront() {
  const { user, logout } = useAuth();
  const [meds, setMeds] = useState([]);
  const [cats, setCats] = useState([]);
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("");
  const [cart, setCart] = useState({});
  const [open, setOpen] = useState(false);
  const [view, setView] = useState("shop");
  const [orders, setOrders] = useState([]);
  const [toast, setToast] = useState("");

  useEffect(() => { api.get("/categories").then((r) => setCats(r.data)); }, []);
  useEffect(() => {
    const t = setTimeout(() => api.get("/catalog", { params: { q, category: cat || undefined } }).then((r) => setMeds(r.data)), 250);
    return () => clearTimeout(t);
  }, [q, cat]);
  useEffect(() => { if (view === "orders") api.get("/orders/mine").then((r) => setOrders(r.data)); }, [view]);

  const say = (m) => { setToast(m); setTimeout(() => setToast(""), 3500); };
  const add = (m, d = 1) => setCart((c) => {
    const qty = (c[m.id]?.qty || 0) + d, n = { ...c };
    if (qty <= 0) delete n[m.id]; else n[m.id] = { m, qty };
    return n;
  });
  const lines = Object.values(cart);
  const count = lines.reduce((s, l) => s + l.qty, 0);
  const total = lines.reduce((s, l) => s + l.qty * Number(l.m.price), 0);
  const send = async () => {
    try {
      const r = await api.post("/orders", { items: lines.map((l) => ({ medicationId: l.m.id, quantity: l.qty })) });
      setCart({}); setOpen(false); setView("orders"); say(`Commande ${r.data.number} envoyée`);
    } catch (e) { say(e.response?.data?.error || "Erreur lors de l'envoi"); }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800">
      <header className="sticky top-0 z-20 bg-white shadow-sm">
        <div className="mx-auto flex max-w-6xl items-center gap-4 px-4 py-3">
          <button onClick={() => setView("shop")} className="text-xl font-bold italic text-orange-500">Pharma-SHOP</button>
          <div className="flex flex-1 overflow-hidden rounded-lg border-2 border-orange-500">
            <input value={q} onChange={(e) => { setQ(e.target.value); setView("shop"); }} placeholder="Rechercher un médicament ou un principe actif" className="min-w-0 flex-1 px-3 py-2 text-sm outline-none" />
            <span className="grid w-12 place-items-center bg-orange-500 text-white"><Search size={18} /></span>
          </div>
          <button onClick={() => setView("orders")} className="hidden flex-col items-center text-xs text-slate-500 hover:text-orange-500 sm:flex"><Package size={20} />Commandes</button>
          <button onClick={() => setOpen(true)} className="relative flex flex-col items-center text-xs text-slate-500 hover:text-orange-500"><ShoppingCart size={20} />Panier
            {count > 0 && <span key={count} className="animate-pop absolute -right-2 -top-2 grid h-5 min-w-5 place-items-center rounded-full bg-orange-500 px-1 text-[11px] font-semibold text-white">{count}</span>}</button>
          <button onClick={logout} aria-label="Déconnexion" className="flex flex-col items-center text-xs text-slate-500 hover:text-orange-500"><LogOut size={20} />Sortir</button>
        </div>
      </header>

      <main className="mx-auto max-w-6xl space-y-8 p-4">
        {view === "shop" ? (<>
          <section className="animate-rise grid items-center gap-4 rounded-2xl bg-gradient-to-r from-emerald-100 to-sky-100 p-8 md:grid-cols-2">
            <div><p className="text-sm text-slate-500">Bonjour {user.name}</p><h1 className="mt-1 text-3xl font-bold text-slate-900">Vos médicaments, prêts à retirer</h1>
              <p className="mt-2 text-slate-600">Commandez en ligne, retirez en pharmacie sans attendre.</p></div>
            <div className="hidden justify-end md:flex"><Pill size={110} className="rotate-12 text-emerald-500/70" /></div>
          </section>

          <section>
            <h2 className="mb-4 font-semibold">Catégories populaires</h2>
            <div className="flex flex-wrap gap-6">
              {[{ id: "", name: "Tous" }, ...cats].map((c, i) => (
                <button key={c.id} onClick={() => setCat(c.id)} className="animate-rise group flex flex-col items-center gap-2 text-sm" style={{ animationDelay: `${i * 60}ms` }}>
                  <span className={`grid h-20 w-20 place-items-center rounded-full border transition group-hover:scale-105 ${cat === c.id ? "border-orange-500 bg-orange-50" : "border-slate-200 bg-[#f3efe8]"}`}><Pill className="text-orange-500" /></span>{c.name}</button>))}
            </div>
          </section>

          <section>
            <h2 className="mb-4 font-semibold">Médicaments</h2>
            {meds.length === 0 ? <p className="text-slate-500">Aucun médicament ne correspond à votre recherche.</p> : (
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                {meds.map((m, i) => (
                  <article key={m.id} className="animate-rise overflow-hidden rounded-xl border border-slate-200 bg-white transition hover:-translate-y-1 hover:shadow-md" style={{ animationDelay: `${Math.min(i, 8) * 50}ms` }}>
                    <div className="relative grid h-36 place-items-center bg-[#f3efe8]"><Pill size={56} className="text-slate-400" />
                      {m.requiresRx && <span className="absolute left-2 top-2 flex items-center gap-1 rounded bg-orange-500 px-1.5 py-0.5 text-[11px] text-white"><ShieldCheck size={12} />Ordonnance</span>}</div>
                    <div className="space-y-1 p-4 text-center">
                      <h3 className="font-medium">{m.name}</h3><p className="text-xs text-slate-500">{m.activeIngredient} · {m.dosage} · {m.form}</p>
                      <p className="font-semibold text-blue-600">{fmt(m.price)}</p>
                      {m.inStock ? <button onClick={() => add(m)} className="mt-2 w-full rounded-full border border-orange-500 py-1.5 text-sm text-orange-600 transition hover:bg-orange-500 hover:text-white active:scale-95">Ajouter au panier</button>
                        : <p className="mt-2 rounded-full bg-slate-100 py-1.5 text-sm text-slate-500">Indisponible</p>}
                    </div>
                  </article>))}
              </div>)}
          </section>
        </>) : (
          <section className="space-y-3">
            <h2 className="font-semibold">Mes commandes</h2>
            {orders.length === 0 && <p className="text-slate-500">Vous n'avez pas encore de commande.</p>}
            {orders.map((o) => (
              <article key={o.id} className="animate-rise rounded-xl border border-slate-200 bg-white p-4">
                <div className="flex flex-wrap items-center justify-between gap-2"><p className="font-medium">{o.number}</p><span className={`rounded-full px-2.5 py-1 text-xs font-medium ${STATUS[o.status]}`}>{o.status.replace("_", " ")}</span></div>
                <p className="mt-1 text-sm text-slate-500">{o.items.map((i) => `${i.quantity} × ${i.medication.name}`).join(", ")}</p>
                <div className="mt-2 flex items-center justify-between text-sm"><span className="font-semibold">{fmt(o.items.reduce((s, i) => s + i.quantity * Number(i.unitPrice), 0))}</span>
                  {o.sale && <a href={`/api/sales/${o.sale.id}/invoice.pdf`} target="_blank" rel="noreferrer" className="flex items-center gap-1 text-orange-600 hover:underline"><FileText size={16} />Facture PDF</a>}</div>
                {o.comment && <p className="mt-2 text-sm text-slate-500">Note : {o.comment}</p>}
              </article>))}
          </section>)}
      </main>

      {open && <div className="fixed inset-0 z-30 bg-black/30" onClick={() => setOpen(false)} />}
      <aside className={`fixed right-0 top-0 z-40 flex h-full w-full max-w-sm flex-col bg-white shadow-xl transition-transform duration-300 ${open ? "translate-x-0" : "translate-x-full"}`}>
        <div className="flex items-center justify-between border-b p-4"><h2 className="font-semibold">Mon panier</h2><button aria-label="Fermer" onClick={() => setOpen(false)}><X /></button></div>
        <div className="flex-1 space-y-3 overflow-y-auto p-4">
          {lines.length === 0 && <p className="text-slate-500">Votre panier est vide.</p>}
          {lines.map(({ m, qty }) => (
            <div key={m.id} className="animate-pop flex items-center justify-between gap-2 rounded-xl bg-slate-50 p-3 text-sm">
              <div><p className="font-medium">{m.name}</p><p className="text-slate-500">{fmt(m.price)}</p></div>
              <div className="flex items-center gap-2"><button aria-label="Moins" onClick={() => add(m, -1)} className="rounded-full border p-1"><Minus size={14} /></button><span className="w-5 text-center">{qty}</span><button aria-label="Plus" onClick={() => add(m, 1)} className="rounded-full border p-1"><Plus size={14} /></button></div>
            </div>))}
        </div>
        <div className="space-y-3 border-t p-4"><div className="flex justify-between font-semibold"><span>Total</span><span>{fmt(total)}</span></div>
          <button disabled={!lines.length} onClick={send} className="w-full rounded-xl bg-orange-500 py-3 font-medium text-white transition hover:bg-orange-600 disabled:opacity-40">Envoyer la commande</button></div>
      </aside>
      {toast && <div role="status" className="animate-pop fixed bottom-6 left-1/2 z-50 -translate-x-1/2 rounded-full bg-slate-900 px-5 py-2.5 text-sm text-white">{toast}</div>}
    </div>
  );
}

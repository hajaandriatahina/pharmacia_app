import { useState } from "react";
import { Pill, HeartPulse } from "lucide-react";
import { api } from "../api.js";
import { useAuth } from "../auth.js";

export default function Login() {
  const { setUser } = useAuth();
  const [mode, setMode] = useState("login");
  const [f, setF] = useState({ name: "", email: "", password: "" });
  const [err, setErr] = useState("");
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const submit = async (e) => {
    e.preventDefault(); setErr("");
    try { const r = await api.post(mode === "login" ? "/auth/login" : "/auth/register", f); setUser(r.data); }
    catch (x) { setErr(x.response?.data?.error || "Erreur de connexion"); }
  };
  const input = "w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20";
  return (
    <div className="grid min-h-screen bg-emerald-50 lg:grid-cols-2">
      <div className="hidden flex-col justify-between bg-[#0f3d36] p-12 text-white lg:flex">
        <div className="flex items-center gap-2 text-xl font-semibold"><HeartPulse /> Pharma-SHOP</div>
        <div className="animate-rise">
          <Pill size={72} className="mb-6 text-emerald-300" />
          <h1 className="text-4xl font-semibold leading-tight">Plus proche<br />de votre santé</h1>
          <p className="mt-3 max-w-sm text-emerald-100/80">Gérez votre stock, vos ventes et vos commandes en un seul endroit.</p>
        </div>
        <p className="text-sm text-emerald-100/60">Application de gestion de pharmacie</p>
      </div>
      <div className="grid place-items-center p-6">
        <form onSubmit={submit} className="animate-pop w-full max-w-sm space-y-4 rounded-3xl bg-white p-8 shadow-sm">
          <h2 className="text-2xl font-semibold text-slate-900">{mode === "login" ? "Connexion" : "Créer un compte client"}</h2>
          {mode === "register" && <input className={input} placeholder="Nom complet" value={f.name} onChange={set("name")} required />}
          <input className={input} type="email" placeholder="Email" value={f.email} onChange={set("email")} required />
          <input className={input} type="password" placeholder="Mot de passe (8 caractères min.)" value={f.password} onChange={set("password")} required />
          {err && <p role="alert" className="rounded-lg bg-rose-50 px-3 py-2 text-sm text-rose-700">{err}</p>}
          <button className="w-full rounded-xl bg-emerald-600 py-3 font-medium text-white transition hover:bg-emerald-700 active:scale-[.98]">{mode === "login" ? "Se connecter" : "S'inscrire"}</button>
          <button type="button" onClick={() => setMode(mode === "login" ? "register" : "login")} className="w-full text-sm text-slate-500 hover:text-emerald-700">
            {mode === "login" ? "Pas de compte ? Créer un compte client" : "Déjà un compte ? Se connecter"}
          </button>
        </form>
      </div>
    </div>
  );
}

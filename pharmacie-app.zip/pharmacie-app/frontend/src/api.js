import axios from "axios";
export const api = axios.create({ baseURL: "/api" });
export const fmt = (n) => Number(n || 0).toLocaleString("fr-FR") + " Ar";

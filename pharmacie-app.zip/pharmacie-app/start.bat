@echo off
start "API" cmd /k "cd backend && npm run dev"
start "WEB" cmd /k "cd frontend && npm run dev"

# Pharma-SHOP — gestion de pharmacie (React + Tailwind + Express + Prisma + MySQL)

## Installation (Windows)
1. Installer Node.js 20+ et MySQL ; créer la base : `CREATE DATABASE pharmacie;` (MySQL Workbench)
2. `cd backend` puis `copy .env.example .env` et renseigner `DATABASE_URL` et `JWT_SECRET`
3. `npm install` ; `npx prisma migrate dev --name init` ; `npm run seed`
4. `cd ..\frontend` ; `npm install`
5. Lancer : `start.bat` (ou `npm run dev` dans chaque dossier) → http://localhost:5173

## Comptes de démonstration (mot de passe `Changer123!` — à changer)
admin@pharma.local · responsable@pharma.local · client@pharma.local

## État
Fait : auth par rôles, catalogue client, panier, commandes, réservations FEFO, ventes (API), factures PDF, alertes stock/péremption, tableau de bord, API médicaments/lots/utilisateurs.
À venir : écrans personnel (POS, médicaments/lots, commandes, utilisateurs), tests automatisés, sauvegarde/restauration MySQL.
